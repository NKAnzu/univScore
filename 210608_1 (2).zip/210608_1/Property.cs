﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _210608_1
{
    class Property //학기,학년 , 과목종류, 과목이름, 학점 ,등급 성적
    {
        public string syear{ set; get; }
        public string year { set; get; }
        public string type { set; get; }
        public string subject { set; get; }
        public string sgrade { set; get; } //학점
        public string grade { set; get; } //등급
        public string score { set; get; }
    }
}
