﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace _210608_1
{
    class DBProperty
    {
        private const string SERVER = "localhost";
        private const string DATABASE = "allgradescore";
        private const string UID = "root";
        private const string PASSWORD = "1234";
        private MySqlConnection conn;
        public int syear { set; get; }
        public int year { set; get; }
        public string type { set; get; }
        public string subject { set; get; }
        public int sgrade { set; get; } //학점
        public string grade { set; get; } //등급
        public float score { set; get; }
        public void InitializeDB()
        {
            //MySql과 연동한다 알트엔터하면 using 바로 됨
            MySqlConnectionStringBuilder builder = new MySqlConnectionStringBuilder();
            builder.Server = SERVER;
            builder.UserID = UID;
            builder.Password = PASSWORD;
            builder.Database = DATABASE;
            string connstr = builder.ToString();
            builder = null;
            conn = new MySqlConnection(connstr);// (호출할떄  connstr)
        }
        public void Insert(List<string> q)
        {
            conn.Close();
            conn.Open();
            string query = "INSERT INTO allsemester(학기,학년,과목분류,과목이름,학점,등급,성적) VALUES("
                            + q[0] + "," + q[1] + ",'" + q[2] + "','" + q[3]
                            + "'," + q[4] + ",'" + q[5] + "'," + q[6] + ")";
            MySqlCommand cmd = new MySqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        public List<DBProperty> GetInfo()
        {
            conn.Close();
            List<DBProperty> dbp = new List<DBProperty>();
            string query = "select * from allsemester";
            MySqlCommand cmd = new MySqlCommand(query, conn);
            conn.Open();
            MySqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                //테이블 갖고있는 데이터 뽑아오림
                int sy = (int)rd["학기"];
                int y = (int)rd["학년"];
                string t = (string)rd["과목분류"];
                string sb = (string)rd["과목이름"];
                int sg = (int)rd["학점"];
                string g = (string)rd["등급"];
                float s = (float)rd["성적"];

                //방금 읽은 레코드 DBProperty에 옮겨 담기
                DBProperty db = new DBProperty();
                db.syear = sy;
                db.year = y;
                db.type = t;
                db.subject = sb;
                db.sgrade = sg;
                db.grade = g;
                db.score = s;

                dbp.Add(db);// 리스트 자료구조에 담기 
            }
            conn.Close();
            return dbp;
        }
    }
}
