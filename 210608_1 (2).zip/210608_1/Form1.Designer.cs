﻿    namespace _210608_1
    {
        partial class Form1
        {
            /// <summary>
            ///  Required designer variable.
            /// </summary>
            private System.ComponentModel.IContainer components = null;

            /// <summary>
            ///  Clean up any resources being used.
            /// </summary>
            /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
            protected override void Dispose(bool disposing)
            {
                if (disposing && (components != null))
                {
                    components.Dispose();
                }
                base.Dispose(disposing);
            }

            #region Windows Form Designer generated code

            /// <summary>
            ///  Required method for Designer support - do not modify
            ///  the contents of this method with the code editor.
            /// </summary>
            private void InitializeComponent()
            {
            this.label1 = new System.Windows.Forms.Label();
            this.lblSub1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblSub2 = new System.Windows.Forms.Label();
            this.lblSub3 = new System.Windows.Forms.Label();
            this.lblSub4 = new System.Windows.Forms.Label();
            this.lblSub5 = new System.Windows.Forms.Label();
            this.lblSub6 = new System.Windows.Forms.Label();
            this.lblSub7 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.tbSubject = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tbScore = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbSGrade = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.rdo1 = new System.Windows.Forms.RadioButton();
            this.rdo2 = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rdo4 = new System.Windows.Forms.RadioButton();
            this.rdo3 = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rdoG4 = new System.Windows.Forms.RadioButton();
            this.rdoG3 = new System.Windows.Forms.RadioButton();
            this.rdoG1 = new System.Windows.Forms.RadioButton();
            this.label14 = new System.Windows.Forms.Label();
            this.rdoG2 = new System.Windows.Forms.RadioButton();
            this.lblSG7 = new System.Windows.Forms.Label();
            this.lblSG6 = new System.Windows.Forms.Label();
            this.lblSG5 = new System.Windows.Forms.Label();
            this.lblSG4 = new System.Windows.Forms.Label();
            this.lblSG3 = new System.Windows.Forms.Label();
            this.lblSG2 = new System.Windows.Forms.Label();
            this.lblSG1 = new System.Windows.Forms.Label();
            this.lblS7 = new System.Windows.Forms.Label();
            this.lblS6 = new System.Windows.Forms.Label();
            this.lblS5 = new System.Windows.Forms.Label();
            this.lblS4 = new System.Windows.Forms.Label();
            this.lblS3 = new System.Windows.Forms.Label();
            this.lblS2 = new System.Windows.Forms.Label();
            this.lblS1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblAvgScore = new System.Windows.Forms.Label();
            this.btnY1B1 = new System.Windows.Forms.Button();
            this.btnY1B2 = new System.Windows.Forms.Button();
            this.btnY2B1 = new System.Windows.Forms.Button();
            this.btnY2B2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.lblsubtype1 = new System.Windows.Forms.Label();
            this.lblsubtype2 = new System.Windows.Forms.Label();
            this.lblsubtype3 = new System.Windows.Forms.Label();
            this.lblsubtype4 = new System.Windows.Forms.Label();
            this.lblsubtype5 = new System.Windows.Forms.Label();
            this.lblsubtype6 = new System.Windows.Forms.Label();
            this.lblsubtype7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblyear1 = new System.Windows.Forms.Label();
            this.lblyear2 = new System.Windows.Forms.Label();
            this.lblyear3 = new System.Windows.Forms.Label();
            this.lblyear4 = new System.Windows.Forms.Label();
            this.lblyear5 = new System.Windows.Forms.Label();
            this.lblyear6 = new System.Windows.Forms.Label();
            this.lblyear7 = new System.Windows.Forms.Label();
            this.lblG1 = new System.Windows.Forms.Label();
            this.lblG2 = new System.Windows.Forms.Label();
            this.lblG3 = new System.Windows.Forms.Label();
            this.lblG4 = new System.Windows.Forms.Label();
            this.lblG5 = new System.Windows.Forms.Label();
            this.lblG6 = new System.Windows.Forms.Label();
            this.lblG7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblSub8 = new System.Windows.Forms.Label();
            this.lblyear8 = new System.Windows.Forms.Label();
            this.lblSG8 = new System.Windows.Forms.Label();
            this.lblS8 = new System.Windows.Forms.Label();
            this.lblsubtype8 = new System.Windows.Forms.Label();
            this.lblG8 = new System.Windows.Forms.Label();
            this.btnY3B1 = new System.Windows.Forms.Button();
            this.btnY3B2 = new System.Windows.Forms.Button();
            this.btnY4B1 = new System.Windows.Forms.Button();
            this.btnY4B2 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.rdoSY2 = new System.Windows.Forms.RadioButton();
            this.rdoSY1 = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblAllScore = new System.Windows.Forms.Label();
            this.lblRestSGrade = new System.Windows.Forms.Label();
            this.btnAllScore = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "과목";
            // 
            // lblSub1
            // 
            this.lblSub1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblSub1.Location = new System.Drawing.Point(45, 77);
            this.lblSub1.Name = "lblSub1";
            this.lblSub1.Size = new System.Drawing.Size(121, 14);
            this.lblSub1.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(259, 34);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 6;
            this.label7.Text = "학점";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(338, 34);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 7;
            this.label8.Text = "성적";
            // 
            // lblSub2
            // 
            this.lblSub2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblSub2.Location = new System.Drawing.Point(45, 118);
            this.lblSub2.Name = "lblSub2";
            this.lblSub2.Size = new System.Drawing.Size(121, 14);
            this.lblSub2.TabIndex = 8;
            // 
            // lblSub3
            // 
            this.lblSub3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblSub3.Location = new System.Drawing.Point(45, 159);
            this.lblSub3.Name = "lblSub3";
            this.lblSub3.Size = new System.Drawing.Size(121, 14);
            this.lblSub3.TabIndex = 9;
            // 
            // lblSub4
            // 
            this.lblSub4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblSub4.Location = new System.Drawing.Point(45, 197);
            this.lblSub4.Name = "lblSub4";
            this.lblSub4.Size = new System.Drawing.Size(121, 14);
            this.lblSub4.TabIndex = 10;
            // 
            // lblSub5
            // 
            this.lblSub5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblSub5.Location = new System.Drawing.Point(45, 229);
            this.lblSub5.Name = "lblSub5";
            this.lblSub5.Size = new System.Drawing.Size(121, 14);
            this.lblSub5.TabIndex = 11;
            // 
            // lblSub6
            // 
            this.lblSub6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblSub6.Location = new System.Drawing.Point(45, 266);
            this.lblSub6.Name = "lblSub6";
            this.lblSub6.Size = new System.Drawing.Size(121, 14);
            this.lblSub6.TabIndex = 12;
            // 
            // lblSub7
            // 
            this.lblSub7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblSub7.Location = new System.Drawing.Point(45, 302);
            this.lblSub7.Name = "lblSub7";
            this.lblSub7.Size = new System.Drawing.Size(121, 14);
            this.lblSub7.TabIndex = 13;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(665, 394);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(103, 46);
            this.btnAdd.TabIndex = 14;
            this.btnAdd.Text = "과목 추가";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // tbSubject
            // 
            this.tbSubject.Location = new System.Drawing.Point(102, 13);
            this.tbSubject.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbSubject.Name = "tbSubject";
            this.tbSubject.Size = new System.Drawing.Size(146, 21);
            this.tbSubject.TabIndex = 15;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(19, 15);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 12);
            this.label11.TabIndex = 16;
            this.label11.Text = "과목 이름 :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(19, 69);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 12);
            this.label12.TabIndex = 17;
            this.label12.Text = "성적 입력 :";
            // 
            // tbScore
            // 
            this.tbScore.Location = new System.Drawing.Point(102, 69);
            this.tbScore.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbScore.Name = "tbScore";
            this.tbScore.Size = new System.Drawing.Size(146, 21);
            this.tbScore.TabIndex = 18;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(19, 16);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(59, 12);
            this.label13.TabIndex = 19;
            this.label13.Text = "전공/교양";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbSGrade);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.tbSubject);
            this.groupBox1.Controls.Add(this.tbScore);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Location = new System.Drawing.Point(665, 35);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(352, 96);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "신규 과목 성적 입력";
            // 
            // tbSGrade
            // 
            this.tbSGrade.Location = new System.Drawing.Point(102, 42);
            this.tbSGrade.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbSGrade.Name = "tbSGrade";
            this.tbSGrade.Size = new System.Drawing.Size(146, 21);
            this.tbSGrade.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 12);
            this.label2.TabIndex = 20;
            this.label2.Text = "학점 입력 : ";
            // 
            // rdo1
            // 
            this.rdo1.AutoSize = true;
            this.rdo1.Location = new System.Drawing.Point(106, 28);
            this.rdo1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdo1.Name = "rdo1";
            this.rdo1.Size = new System.Drawing.Size(71, 16);
            this.rdo1.TabIndex = 20;
            this.rdo1.TabStop = true;
            this.rdo1.Text = "전공필수";
            this.rdo1.UseVisualStyleBackColor = true;
            // 
            // rdo2
            // 
            this.rdo2.AutoSize = true;
            this.rdo2.Location = new System.Drawing.Point(215, 28);
            this.rdo2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdo2.Name = "rdo2";
            this.rdo2.Size = new System.Drawing.Size(71, 16);
            this.rdo2.TabIndex = 21;
            this.rdo2.TabStop = true;
            this.rdo2.Text = "전공선택";
            this.rdo2.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rdo4);
            this.groupBox2.Controls.Add(this.rdo3);
            this.groupBox2.Controls.Add(this.rdo2);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.rdo1);
            this.groupBox2.Location = new System.Drawing.Point(665, 146);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(352, 96);
            this.groupBox2.TabIndex = 22;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "신규 과목 종류 입력";
            // 
            // rdo4
            // 
            this.rdo4.AutoSize = true;
            this.rdo4.Location = new System.Drawing.Point(215, 66);
            this.rdo4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdo4.Name = "rdo4";
            this.rdo4.Size = new System.Drawing.Size(71, 16);
            this.rdo4.TabIndex = 23;
            this.rdo4.TabStop = true;
            this.rdo4.Text = "교양선택";
            this.rdo4.UseVisualStyleBackColor = true;
            // 
            // rdo3
            // 
            this.rdo3.AutoSize = true;
            this.rdo3.Location = new System.Drawing.Point(106, 66);
            this.rdo3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdo3.Name = "rdo3";
            this.rdo3.Size = new System.Drawing.Size(71, 16);
            this.rdo3.TabIndex = 22;
            this.rdo3.TabStop = true;
            this.rdo3.Text = "교양필수";
            this.rdo3.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rdoG4);
            this.groupBox3.Controls.Add(this.rdoG3);
            this.groupBox3.Controls.Add(this.rdoG1);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.rdoG2);
            this.groupBox3.Location = new System.Drawing.Point(665, 254);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Size = new System.Drawing.Size(352, 68);
            this.groupBox3.TabIndex = 23;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "신규 과목 학년 입력";
            // 
            // rdoG4
            // 
            this.rdoG4.AutoSize = true;
            this.rdoG4.Location = new System.Drawing.Point(215, 48);
            this.rdoG4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdoG4.Name = "rdoG4";
            this.rdoG4.Size = new System.Drawing.Size(29, 16);
            this.rdoG4.TabIndex = 28;
            this.rdoG4.TabStop = true;
            this.rdoG4.Text = "4";
            this.rdoG4.UseVisualStyleBackColor = true;
            // 
            // rdoG3
            // 
            this.rdoG3.AutoSize = true;
            this.rdoG3.Location = new System.Drawing.Point(106, 48);
            this.rdoG3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdoG3.Name = "rdoG3";
            this.rdoG3.Size = new System.Drawing.Size(29, 16);
            this.rdoG3.TabIndex = 27;
            this.rdoG3.TabStop = true;
            this.rdoG3.Text = "3";
            this.rdoG3.UseVisualStyleBackColor = true;
            // 
            // rdoG1
            // 
            this.rdoG1.AutoSize = true;
            this.rdoG1.Location = new System.Drawing.Point(106, 15);
            this.rdoG1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdoG1.Name = "rdoG1";
            this.rdoG1.Size = new System.Drawing.Size(29, 16);
            this.rdoG1.TabIndex = 25;
            this.rdoG1.TabStop = true;
            this.rdoG1.Text = "1";
            this.rdoG1.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(19, 15);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 12);
            this.label14.TabIndex = 24;
            this.label14.Text = "학년";
            // 
            // rdoG2
            // 
            this.rdoG2.AutoSize = true;
            this.rdoG2.Location = new System.Drawing.Point(215, 15);
            this.rdoG2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdoG2.Name = "rdoG2";
            this.rdoG2.Size = new System.Drawing.Size(29, 16);
            this.rdoG2.TabIndex = 26;
            this.rdoG2.TabStop = true;
            this.rdoG2.Text = "2";
            this.rdoG2.UseVisualStyleBackColor = true;
            // 
            // lblSG7
            // 
            this.lblSG7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblSG7.Location = new System.Drawing.Point(259, 302);
            this.lblSG7.Name = "lblSG7";
            this.lblSG7.Size = new System.Drawing.Size(54, 14);
            this.lblSG7.TabIndex = 30;
            // 
            // lblSG6
            // 
            this.lblSG6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblSG6.Location = new System.Drawing.Point(259, 266);
            this.lblSG6.Name = "lblSG6";
            this.lblSG6.Size = new System.Drawing.Size(54, 14);
            this.lblSG6.TabIndex = 29;
            // 
            // lblSG5
            // 
            this.lblSG5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblSG5.Location = new System.Drawing.Point(259, 229);
            this.lblSG5.Name = "lblSG5";
            this.lblSG5.Size = new System.Drawing.Size(54, 14);
            this.lblSG5.TabIndex = 28;
            // 
            // lblSG4
            // 
            this.lblSG4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblSG4.Location = new System.Drawing.Point(259, 197);
            this.lblSG4.Name = "lblSG4";
            this.lblSG4.Size = new System.Drawing.Size(54, 14);
            this.lblSG4.TabIndex = 27;
            // 
            // lblSG3
            // 
            this.lblSG3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblSG3.Location = new System.Drawing.Point(259, 159);
            this.lblSG3.Name = "lblSG3";
            this.lblSG3.Size = new System.Drawing.Size(54, 14);
            this.lblSG3.TabIndex = 26;
            // 
            // lblSG2
            // 
            this.lblSG2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblSG2.Location = new System.Drawing.Point(259, 118);
            this.lblSG2.Name = "lblSG2";
            this.lblSG2.Size = new System.Drawing.Size(54, 14);
            this.lblSG2.TabIndex = 25;
            // 
            // lblSG1
            // 
            this.lblSG1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblSG1.Location = new System.Drawing.Point(259, 77);
            this.lblSG1.Name = "lblSG1";
            this.lblSG1.Size = new System.Drawing.Size(54, 14);
            this.lblSG1.TabIndex = 24;
            // 
            // lblS7
            // 
            this.lblS7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblS7.Location = new System.Drawing.Point(338, 302);
            this.lblS7.Name = "lblS7";
            this.lblS7.Size = new System.Drawing.Size(54, 14);
            this.lblS7.TabIndex = 37;
            // 
            // lblS6
            // 
            this.lblS6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblS6.Location = new System.Drawing.Point(338, 266);
            this.lblS6.Name = "lblS6";
            this.lblS6.Size = new System.Drawing.Size(54, 14);
            this.lblS6.TabIndex = 36;
            // 
            // lblS5
            // 
            this.lblS5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblS5.Location = new System.Drawing.Point(338, 229);
            this.lblS5.Name = "lblS5";
            this.lblS5.Size = new System.Drawing.Size(54, 14);
            this.lblS5.TabIndex = 35;
            // 
            // lblS4
            // 
            this.lblS4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblS4.Location = new System.Drawing.Point(338, 197);
            this.lblS4.Name = "lblS4";
            this.lblS4.Size = new System.Drawing.Size(54, 14);
            this.lblS4.TabIndex = 34;
            // 
            // lblS3
            // 
            this.lblS3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblS3.Location = new System.Drawing.Point(338, 159);
            this.lblS3.Name = "lblS3";
            this.lblS3.Size = new System.Drawing.Size(54, 14);
            this.lblS3.TabIndex = 33;
            // 
            // lblS2
            // 
            this.lblS2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblS2.Location = new System.Drawing.Point(338, 118);
            this.lblS2.Name = "lblS2";
            this.lblS2.Size = new System.Drawing.Size(54, 14);
            this.lblS2.TabIndex = 32;
            // 
            // lblS1
            // 
            this.lblS1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblS1.Location = new System.Drawing.Point(338, 77);
            this.lblS1.Name = "lblS1";
            this.lblS1.Size = new System.Drawing.Size(54, 14);
            this.lblS1.TabIndex = 31;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(45, 370);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 12);
            this.label3.TabIndex = 21;
            this.label3.Text = "학년 평균 성적 :";
            // 
            // lblAvgScore
            // 
            this.lblAvgScore.BackColor = System.Drawing.Color.Aqua;
            this.lblAvgScore.Location = new System.Drawing.Point(144, 370);
            this.lblAvgScore.Name = "lblAvgScore";
            this.lblAvgScore.Size = new System.Drawing.Size(49, 18);
            this.lblAvgScore.TabIndex = 38;
            // 
            // btnY1B1
            // 
            this.btnY1B1.Location = new System.Drawing.Point(45, 394);
            this.btnY1B1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnY1B1.Name = "btnY1B1";
            this.btnY1B1.Size = new System.Drawing.Size(48, 46);
            this.btnY1B1.TabIndex = 39;
            this.btnY1B1.Text = "1학년 1학기";
            this.btnY1B1.UseVisualStyleBackColor = true;
            this.btnY1B1.Click += new System.EventHandler(this.btnY1_Click);
            // 
            // btnY1B2
            // 
            this.btnY1B2.Location = new System.Drawing.Point(117, 394);
            this.btnY1B2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnY1B2.Name = "btnY1B2";
            this.btnY1B2.Size = new System.Drawing.Size(49, 46);
            this.btnY1B2.TabIndex = 40;
            this.btnY1B2.Text = "1학년 2학기";
            this.btnY1B2.UseVisualStyleBackColor = true;
            this.btnY1B2.Click += new System.EventHandler(this.btnY2_Click);
            // 
            // btnY2B1
            // 
            this.btnY2B1.Location = new System.Drawing.Point(187, 394);
            this.btnY2B1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnY2B1.Name = "btnY2B1";
            this.btnY2B1.Size = new System.Drawing.Size(49, 46);
            this.btnY2B1.TabIndex = 41;
            this.btnY2B1.Text = "2학년 1학기";
            this.btnY2B1.UseVisualStyleBackColor = true;
            this.btnY2B1.Click += new System.EventHandler(this.btnY3_Click);
            // 
            // btnY2B2
            // 
            this.btnY2B2.Location = new System.Drawing.Point(259, 394);
            this.btnY2B2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnY2B2.Name = "btnY2B2";
            this.btnY2B2.Size = new System.Drawing.Size(44, 46);
            this.btnY2B2.TabIndex = 42;
            this.btnY2B2.Text = "2학년 2학기";
            this.btnY2B2.UseVisualStyleBackColor = true;
            this.btnY2B2.Click += new System.EventHandler(this.btnY4_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(418, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 43;
            this.label4.Text = "이수구분";
            // 
            // lblsubtype1
            // 
            this.lblsubtype1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblsubtype1.Location = new System.Drawing.Point(414, 77);
            this.lblsubtype1.Name = "lblsubtype1";
            this.lblsubtype1.Size = new System.Drawing.Size(75, 14);
            this.lblsubtype1.TabIndex = 44;
            // 
            // lblsubtype2
            // 
            this.lblsubtype2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblsubtype2.Location = new System.Drawing.Point(414, 118);
            this.lblsubtype2.Name = "lblsubtype2";
            this.lblsubtype2.Size = new System.Drawing.Size(75, 14);
            this.lblsubtype2.TabIndex = 45;
            // 
            // lblsubtype3
            // 
            this.lblsubtype3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblsubtype3.Location = new System.Drawing.Point(414, 159);
            this.lblsubtype3.Name = "lblsubtype3";
            this.lblsubtype3.Size = new System.Drawing.Size(75, 14);
            this.lblsubtype3.TabIndex = 46;
            // 
            // lblsubtype4
            // 
            this.lblsubtype4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblsubtype4.Location = new System.Drawing.Point(414, 197);
            this.lblsubtype4.Name = "lblsubtype4";
            this.lblsubtype4.Size = new System.Drawing.Size(75, 14);
            this.lblsubtype4.TabIndex = 47;
            // 
            // lblsubtype5
            // 
            this.lblsubtype5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblsubtype5.Location = new System.Drawing.Point(414, 229);
            this.lblsubtype5.Name = "lblsubtype5";
            this.lblsubtype5.Size = new System.Drawing.Size(75, 14);
            this.lblsubtype5.TabIndex = 48;
            // 
            // lblsubtype6
            // 
            this.lblsubtype6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblsubtype6.Location = new System.Drawing.Point(414, 266);
            this.lblsubtype6.Name = "lblsubtype6";
            this.lblsubtype6.Size = new System.Drawing.Size(75, 14);
            this.lblsubtype6.TabIndex = 49;
            // 
            // lblsubtype7
            // 
            this.lblsubtype7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblsubtype7.Location = new System.Drawing.Point(414, 302);
            this.lblsubtype7.Name = "lblsubtype7";
            this.lblsubtype7.Size = new System.Drawing.Size(75, 14);
            this.lblsubtype7.TabIndex = 50;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(187, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 51;
            this.label5.Text = "학년";
            // 
            // lblyear1
            // 
            this.lblyear1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblyear1.Location = new System.Drawing.Point(187, 77);
            this.lblyear1.Name = "lblyear1";
            this.lblyear1.Size = new System.Drawing.Size(49, 14);
            this.lblyear1.TabIndex = 52;
            // 
            // lblyear2
            // 
            this.lblyear2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblyear2.Location = new System.Drawing.Point(187, 119);
            this.lblyear2.Name = "lblyear2";
            this.lblyear2.Size = new System.Drawing.Size(49, 12);
            this.lblyear2.TabIndex = 53;
            // 
            // lblyear3
            // 
            this.lblyear3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblyear3.Location = new System.Drawing.Point(187, 161);
            this.lblyear3.Name = "lblyear3";
            this.lblyear3.Size = new System.Drawing.Size(49, 12);
            this.lblyear3.TabIndex = 54;
            // 
            // lblyear4
            // 
            this.lblyear4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblyear4.Location = new System.Drawing.Point(187, 197);
            this.lblyear4.Name = "lblyear4";
            this.lblyear4.Size = new System.Drawing.Size(49, 12);
            this.lblyear4.TabIndex = 55;
            // 
            // lblyear5
            // 
            this.lblyear5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblyear5.Location = new System.Drawing.Point(187, 229);
            this.lblyear5.Name = "lblyear5";
            this.lblyear5.Size = new System.Drawing.Size(49, 12);
            this.lblyear5.TabIndex = 56;
            // 
            // lblyear6
            // 
            this.lblyear6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblyear6.Location = new System.Drawing.Point(187, 266);
            this.lblyear6.Name = "lblyear6";
            this.lblyear6.Size = new System.Drawing.Size(49, 12);
            this.lblyear6.TabIndex = 57;
            // 
            // lblyear7
            // 
            this.lblyear7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblyear7.Location = new System.Drawing.Point(187, 302);
            this.lblyear7.Name = "lblyear7";
            this.lblyear7.Size = new System.Drawing.Size(49, 12);
            this.lblyear7.TabIndex = 58;
            // 
            // lblG1
            // 
            this.lblG1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblG1.Location = new System.Drawing.Point(512, 77);
            this.lblG1.Name = "lblG1";
            this.lblG1.Size = new System.Drawing.Size(75, 14);
            this.lblG1.TabIndex = 59;
            // 
            // lblG2
            // 
            this.lblG2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblG2.Location = new System.Drawing.Point(512, 118);
            this.lblG2.Name = "lblG2";
            this.lblG2.Size = new System.Drawing.Size(75, 14);
            this.lblG2.TabIndex = 60;
            // 
            // lblG3
            // 
            this.lblG3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblG3.Location = new System.Drawing.Point(512, 159);
            this.lblG3.Name = "lblG3";
            this.lblG3.Size = new System.Drawing.Size(75, 14);
            this.lblG3.TabIndex = 61;
            // 
            // lblG4
            // 
            this.lblG4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblG4.Location = new System.Drawing.Point(512, 197);
            this.lblG4.Name = "lblG4";
            this.lblG4.Size = new System.Drawing.Size(75, 14);
            this.lblG4.TabIndex = 62;
            // 
            // lblG5
            // 
            this.lblG5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblG5.Location = new System.Drawing.Point(512, 227);
            this.lblG5.Name = "lblG5";
            this.lblG5.Size = new System.Drawing.Size(75, 14);
            this.lblG5.TabIndex = 63;
            // 
            // lblG6
            // 
            this.lblG6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblG6.Location = new System.Drawing.Point(512, 265);
            this.lblG6.Name = "lblG6";
            this.lblG6.Size = new System.Drawing.Size(75, 14);
            this.lblG6.TabIndex = 64;
            // 
            // lblG7
            // 
            this.lblG7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblG7.Location = new System.Drawing.Point(512, 300);
            this.lblG7.Name = "lblG7";
            this.lblG7.Size = new System.Drawing.Size(75, 14);
            this.lblG7.TabIndex = 65;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(512, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 66;
            this.label6.Text = "등급";
            // 
            // lblSub8
            // 
            this.lblSub8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblSub8.Location = new System.Drawing.Point(45, 336);
            this.lblSub8.Name = "lblSub8";
            this.lblSub8.Size = new System.Drawing.Size(121, 14);
            this.lblSub8.TabIndex = 67;
            // 
            // lblyear8
            // 
            this.lblyear8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblyear8.Location = new System.Drawing.Point(187, 338);
            this.lblyear8.Name = "lblyear8";
            this.lblyear8.Size = new System.Drawing.Size(49, 12);
            this.lblyear8.TabIndex = 68;
            // 
            // lblSG8
            // 
            this.lblSG8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblSG8.Location = new System.Drawing.Point(259, 336);
            this.lblSG8.Name = "lblSG8";
            this.lblSG8.Size = new System.Drawing.Size(54, 14);
            this.lblSG8.TabIndex = 69;
            // 
            // lblS8
            // 
            this.lblS8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblS8.Location = new System.Drawing.Point(338, 336);
            this.lblS8.Name = "lblS8";
            this.lblS8.Size = new System.Drawing.Size(54, 14);
            this.lblS8.TabIndex = 70;
            // 
            // lblsubtype8
            // 
            this.lblsubtype8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblsubtype8.Location = new System.Drawing.Point(414, 338);
            this.lblsubtype8.Name = "lblsubtype8";
            this.lblsubtype8.Size = new System.Drawing.Size(75, 14);
            this.lblsubtype8.TabIndex = 71;
            // 
            // lblG8
            // 
            this.lblG8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblG8.Location = new System.Drawing.Point(512, 338);
            this.lblG8.Name = "lblG8";
            this.lblG8.Size = new System.Drawing.Size(75, 14);
            this.lblG8.TabIndex = 72;
            // 
            // btnY3B1
            // 
            this.btnY3B1.Location = new System.Drawing.Point(340, 394);
            this.btnY3B1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnY3B1.Name = "btnY3B1";
            this.btnY3B1.Size = new System.Drawing.Size(44, 46);
            this.btnY3B1.TabIndex = 74;
            this.btnY3B1.Text = "3학년 1학기";
            this.btnY3B1.UseVisualStyleBackColor = true;
            this.btnY3B1.Click += new System.EventHandler(this.btnY3B1_Click);
            // 
            // btnY3B2
            // 
            this.btnY3B2.Location = new System.Drawing.Point(406, 394);
            this.btnY3B2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnY3B2.Name = "btnY3B2";
            this.btnY3B2.Size = new System.Drawing.Size(44, 46);
            this.btnY3B2.TabIndex = 75;
            this.btnY3B2.Text = "3학년 2학기";
            this.btnY3B2.UseVisualStyleBackColor = true;
            this.btnY3B2.Click += new System.EventHandler(this.btnY3B2_Click);
            // 
            // btnY4B1
            // 
            this.btnY4B1.Location = new System.Drawing.Point(473, 394);
            this.btnY4B1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnY4B1.Name = "btnY4B1";
            this.btnY4B1.Size = new System.Drawing.Size(44, 46);
            this.btnY4B1.TabIndex = 76;
            this.btnY4B1.Text = "4학년 1학기";
            this.btnY4B1.UseVisualStyleBackColor = true;
            this.btnY4B1.Click += new System.EventHandler(this.btnY4B1_Click);
            // 
            // btnY4B2
            // 
            this.btnY4B2.Location = new System.Drawing.Point(543, 394);
            this.btnY4B2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnY4B2.Name = "btnY4B2";
            this.btnY4B2.Size = new System.Drawing.Size(44, 46);
            this.btnY4B2.TabIndex = 77;
            this.btnY4B2.Text = "4학년 2학기";
            this.btnY4B2.UseVisualStyleBackColor = true;
            this.btnY4B2.Click += new System.EventHandler(this.btnY4B2_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.rdoSY2);
            this.groupBox4.Controls.Add(this.rdoSY1);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Location = new System.Drawing.Point(665, 336);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(352, 46);
            this.groupBox4.TabIndex = 29;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "신규 과목 학기 입력";
            // 
            // rdoSY2
            // 
            this.rdoSY2.AutoSize = true;
            this.rdoSY2.Location = new System.Drawing.Point(215, 25);
            this.rdoSY2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdoSY2.Name = "rdoSY2";
            this.rdoSY2.Size = new System.Drawing.Size(29, 16);
            this.rdoSY2.TabIndex = 29;
            this.rdoSY2.TabStop = true;
            this.rdoSY2.Text = "2";
            this.rdoSY2.UseVisualStyleBackColor = true;
            // 
            // rdoSY1
            // 
            this.rdoSY1.AutoSize = true;
            this.rdoSY1.Location = new System.Drawing.Point(106, 25);
            this.rdoSY1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdoSY1.Name = "rdoSY1";
            this.rdoSY1.Size = new System.Drawing.Size(29, 16);
            this.rdoSY1.TabIndex = 29;
            this.rdoSY1.TabStop = true;
            this.rdoSY1.Text = "1";
            this.rdoSY1.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "학기";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(211, 370);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 12);
            this.label10.TabIndex = 78;
            this.label10.Text = "전체 성적:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(355, 370);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(97, 12);
            this.label15.TabIndex = 79;
            this.label15.Text = "이수해야할 학점:";
            // 
            // lblAllScore
            // 
            this.lblAllScore.BackColor = System.Drawing.Color.Aqua;
            this.lblAllScore.Location = new System.Drawing.Point(283, 370);
            this.lblAllScore.Name = "lblAllScore";
            this.lblAllScore.Size = new System.Drawing.Size(49, 18);
            this.lblAllScore.TabIndex = 80;
            // 
            // lblRestSGrade
            // 
            this.lblRestSGrade.BackColor = System.Drawing.Color.Aqua;
            this.lblRestSGrade.Location = new System.Drawing.Point(468, 370);
            this.lblRestSGrade.Name = "lblRestSGrade";
            this.lblRestSGrade.Size = new System.Drawing.Size(49, 18);
            this.lblRestSGrade.TabIndex = 81;
            // 
            // btnAllScore
            // 
            this.btnAllScore.Location = new System.Drawing.Point(790, 394);
            this.btnAllScore.Name = "btnAllScore";
            this.btnAllScore.Size = new System.Drawing.Size(89, 46);
            this.btnAllScore.TabIndex = 82;
            this.btnAllScore.Text = "전체 성적!";
            this.btnAllScore.UseVisualStyleBackColor = true;
            this.btnAllScore.Click += new System.EventHandler(this.btnAllScore_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1034, 478);
            this.Controls.Add(this.btnAllScore);
            this.Controls.Add(this.lblRestSGrade);
            this.Controls.Add(this.lblAllScore);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.btnY4B2);
            this.Controls.Add(this.btnY4B1);
            this.Controls.Add(this.btnY3B2);
            this.Controls.Add(this.btnY3B1);
            this.Controls.Add(this.lblG8);
            this.Controls.Add(this.lblsubtype8);
            this.Controls.Add(this.lblS8);
            this.Controls.Add(this.lblSG8);
            this.Controls.Add(this.lblyear8);
            this.Controls.Add(this.lblSub8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblG7);
            this.Controls.Add(this.lblG6);
            this.Controls.Add(this.lblG5);
            this.Controls.Add(this.lblG4);
            this.Controls.Add(this.lblG3);
            this.Controls.Add(this.lblG2);
            this.Controls.Add(this.lblG1);
            this.Controls.Add(this.lblyear7);
            this.Controls.Add(this.lblyear6);
            this.Controls.Add(this.lblyear5);
            this.Controls.Add(this.lblyear4);
            this.Controls.Add(this.lblyear3);
            this.Controls.Add(this.lblyear2);
            this.Controls.Add(this.lblyear1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblsubtype7);
            this.Controls.Add(this.lblsubtype6);
            this.Controls.Add(this.lblsubtype5);
            this.Controls.Add(this.lblsubtype4);
            this.Controls.Add(this.lblsubtype3);
            this.Controls.Add(this.lblsubtype2);
            this.Controls.Add(this.lblsubtype1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnY2B2);
            this.Controls.Add(this.btnY2B1);
            this.Controls.Add(this.btnY1B2);
            this.Controls.Add(this.btnY1B1);
            this.Controls.Add(this.lblAvgScore);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblS7);
            this.Controls.Add(this.lblS6);
            this.Controls.Add(this.lblS5);
            this.Controls.Add(this.lblS4);
            this.Controls.Add(this.lblS3);
            this.Controls.Add(this.lblS2);
            this.Controls.Add(this.lblS1);
            this.Controls.Add(this.lblSG7);
            this.Controls.Add(this.lblSG6);
            this.Controls.Add(this.lblSG5);
            this.Controls.Add(this.lblSG4);
            this.Controls.Add(this.lblSG3);
            this.Controls.Add(this.lblSG2);
            this.Controls.Add(this.lblSG1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lblSub7);
            this.Controls.Add(this.lblSub6);
            this.Controls.Add(this.lblSub5);
            this.Controls.Add(this.lblSub4);
            this.Controls.Add(this.lblSub3);
            this.Controls.Add(this.lblSub2);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblSub1);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "학점 계산기";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

            }

            #endregion

            private System.Windows.Forms.Label label1;
            private System.Windows.Forms.Label lblSub1;
            private System.Windows.Forms.Label label7;
            private System.Windows.Forms.Label label8;
            private System.Windows.Forms.Label lblSub2;
            private System.Windows.Forms.Label lblSub3;
            private System.Windows.Forms.Label lblSub4;
            private System.Windows.Forms.Label lblSub5;
            private System.Windows.Forms.Label lblSub6;
            private System.Windows.Forms.Label lblSub7;
            private System.Windows.Forms.Button btnAdd;
            private System.Windows.Forms.TextBox tbSubject;
            private System.Windows.Forms.Label label11;
            private System.Windows.Forms.Label label12;
            private System.Windows.Forms.TextBox tbScore;
            private System.Windows.Forms.Label label13;
            private System.Windows.Forms.GroupBox groupBox1;
            private System.Windows.Forms.RadioButton rdo1;
            private System.Windows.Forms.RadioButton rdo2;
            private System.Windows.Forms.GroupBox groupBox2;
            private System.Windows.Forms.RadioButton rdo4;
            private System.Windows.Forms.RadioButton rdo3;
            private System.Windows.Forms.GroupBox groupBox3;
            private System.Windows.Forms.RadioButton rdoG4;
            private System.Windows.Forms.RadioButton rdoG3;
            private System.Windows.Forms.RadioButton rdoG1;
            private System.Windows.Forms.Label label14;
            private System.Windows.Forms.RadioButton rdoG2;
            private System.Windows.Forms.Label lblSG7;
            private System.Windows.Forms.Label lblSG6;
            private System.Windows.Forms.Label lblSG5;
            private System.Windows.Forms.Label lblSG4;
            private System.Windows.Forms.Label lblSG3;
            private System.Windows.Forms.Label lblSG2;
            private System.Windows.Forms.Label lblSG1;
            private System.Windows.Forms.Label lblS7;
            private System.Windows.Forms.Label lblS6;
            private System.Windows.Forms.Label lblS5;
            private System.Windows.Forms.Label lblS4;
            private System.Windows.Forms.Label lblS3;
            private System.Windows.Forms.Label lblS2;
            private System.Windows.Forms.Label lblS1;
            private System.Windows.Forms.TextBox tbSGrade;
            private System.Windows.Forms.Label label2;
            private System.Windows.Forms.Label label3;
            private System.Windows.Forms.Label lblAvgScore;
            private System.Windows.Forms.Button btnY1B1;
            private System.Windows.Forms.Button btnY1B2;
            private System.Windows.Forms.Button btnY2B1;
            private System.Windows.Forms.Button btnY2B2;
            private System.Windows.Forms.Label label4;
            private System.Windows.Forms.Label lblsubtype1;
            private System.Windows.Forms.Label lblsubtype2;
            private System.Windows.Forms.Label lblsubtype3;
            private System.Windows.Forms.Label lblsubtype4;
            private System.Windows.Forms.Label lblsubtype5;
            private System.Windows.Forms.Label lblsubtype6;
            private System.Windows.Forms.Label lblsubtype7;
            private System.Windows.Forms.Label label5;
            private System.Windows.Forms.Label lblyear1;
            private System.Windows.Forms.Label lblyear2;
            private System.Windows.Forms.Label lblyear3;
            private System.Windows.Forms.Label lblyear4;
            private System.Windows.Forms.Label lblyear5;
            private System.Windows.Forms.Label lblyear6;
            private System.Windows.Forms.Label lblyear7;
            private System.Windows.Forms.Label lbl;
            private System.Windows.Forms.Label lblG1;
            private System.Windows.Forms.Label lblG2;
            private System.Windows.Forms.Label lblG3;
            private System.Windows.Forms.Label lblG4;
            private System.Windows.Forms.Label lblG5;
            private System.Windows.Forms.Label lblG6;
            private System.Windows.Forms.Label lblG7;
            private System.Windows.Forms.Label label6;
            private System.Windows.Forms.Label lblSub8;
            private System.Windows.Forms.Label lblyear8;
            private System.Windows.Forms.Label lblSG8;
            private System.Windows.Forms.Label lblS8;
            private System.Windows.Forms.Label lblsubtype8;
            private System.Windows.Forms.Label lblG8;
        private System.Windows.Forms.Button btnY3B1;
        private System.Windows.Forms.Button btnY3B2;
        private System.Windows.Forms.Button btnY4B1;
        private System.Windows.Forms.Button btnY4B2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton rdoSY2;
        private System.Windows.Forms.RadioButton rdoSY1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblAllScore;
        private System.Windows.Forms.Label lblRestSGrade;
        private System.Windows.Forms.Button btnAllScore;
    }
    }

