﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace _210608_1
{
    public partial class ListForm : Form
    {
        public ListForm()
        {
            InitializeComponent();
        }
    }
}
