﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace _210608_1
{
    
    public partial class Form1 : Form
    {
        DBProperty dbp = new DBProperty();
        double SgradeSum;
        double Sum;
        double avgScore;
        public Form1()
        {
            InitializeComponent();
            dbp.InitializeDB();
        }
        private void functions(string sg, string g)
        {
            SgradeSum = 0;
            Sum = 0;
            avgScore = 0;
            Label[] lblYears = new Label[] { lblyear1, lblyear2, lblyear3, lblyear4, lblyear5, lblyear6, lblyear7, lblyear8 }; //학년
            Label[] lblTypes = new Label[] { lblsubtype1, lblsubtype2, lblsubtype3, lblsubtype4, lblsubtype5, lblsubtype6, lblsubtype7, lblsubtype8 };//이수구분
            Label[] lblSubjects = new Label[] { lblSub1, lblSub2, lblSub3, lblSub4, lblSub5, lblSub6, lblSub7, lblSub8 }; //과목이름
            Label[] lblSGrades = new Label[] { lblSG1, lblSG2, lblSG3, lblSG4, lblSG5, lblSG6, lblSG7, lblSG8 }; // 학점
            Label[] lblGrades = new Label[] { lblG1, lblG2, lblG3, lblG4, lblG5, lblG6, lblG7, lblG8 }; // 등급
            Label[] lblScores = new Label[] { lblS1, lblS2, lblS3, lblS4, lblS5, lblS6, lblS7, lblS8 }; // 성적
            //List<string> temp = new List<string>();
            for (int i = 0; i < 8; i++)
            {
                lblYears[i].Text = "";
                lblTypes[i].Text = "";
                lblSubjects[i].Text = "";
                lblSGrades[i].Text = "";
                lblGrades[i].Text = "";
                lblScores[i].Text = "";
            }
            Property p = new Property();
            List<string> pt = new List<string>();
            List<string> temp2 = new List<string>();
            int cnt = 0;
            int idx = 0;
            OpenFileDialog ofd = new OpenFileDialog();
            List<DBProperty> dbpRead = dbp.GetInfo();
            foreach (DBProperty d in dbpRead)
            {
                pt = new List<string>() { d.syear.ToString(), d.year.ToString()
                    , d.type, d.subject, d.sgrade.ToString(), d.grade, d.score.ToString() };
                for (int k = 0; k < pt.Count; k++)
                {
                    if (pt[k] == "" && cnt != 0)
                    {
                        pt[k] = temp2[k];
                    }
                }
                if (pt[0] == sg && pt[1] == g)
                {
                    lblYears[cnt].Text = pt[1];
                    lblTypes[cnt].Text = pt[2];
                    lblSubjects[cnt].Text = pt[3];
                    lblSGrades[cnt].Text = pt[4];
                    lblGrades[cnt].Text = pt[5];
                    lblScores[cnt].Text = pt[6];
                    idx++;
                    cnt++;
                }
                temp2 = pt;
            }
            for (int j = cnt; j < 8; j++)
            {
                lblYears[cnt].Text = null;
                lblTypes[cnt].Text = null;
                lblSubjects[cnt].Text = null;
                lblSGrades[cnt].Text = null;
                lblGrades[cnt].Text = null;
                lblScores[cnt].Text = null;
            }
            for (int i = 0; i < idx; i++)
            {
                if (lblGrades[i].Text != "S")
                {
                    Sum += Double.Parse(lblSGrades[i].Text) * Double.Parse(lblScores[i].Text);
                    SgradeSum += Double.Parse(lblSGrades[i].Text);
                }
            }
            avgScore = Sum / SgradeSum;
            lblAvgScore.Text = avgScore.ToString();
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            int cnt = 0;

            Label[] lblYears = new Label[] { lblyear1, lblyear2, lblyear3, lblyear4, lblyear5, lblyear6, lblyear7, lblyear8 }; //학년
            Label[] lblTypes = new Label[] { lblsubtype1, lblsubtype2, lblsubtype3, lblsubtype4, lblsubtype5, lblsubtype6, lblsubtype7, lblsubtype8 };//이수구분
            Label[] lblSubjects = new Label[] { lblSub1, lblSub2, lblSub3, lblSub4, lblSub5, lblSub6, lblSub7, lblSub8 }; //과목이름
            Label[] lblSGrades = new Label[] { lblSG1, lblSG2, lblSG3, lblSG4, lblSG5, lblSG6, lblSG7, lblSG8 }; // 학점
            Label[] lblGrades = new Label[] { lblG1, lblG2, lblG3, lblG4, lblG5, lblG6, lblG7, lblG8 }; // 등급
            Label[] lblScores = new Label[] { lblS1, lblS2, lblS3, lblS4, lblS5, lblS6, lblS7, lblS8 }; // 성적

            if (tbScore.Text == "" || tbSGrade.Text == "" || tbSubject.Text == "" || 0 > Double.Parse(tbScore.Text) || Double.Parse(tbScore.Text) > 4.5)
            {
                MessageBox.Show("값을 제대로 입력하고 버튼을 눌러주세요");
            }
            else
            {
                if (lblSubjects[7].Text != "")
                {
                    MessageBox.Show("더이상 추가할수 없습니다.");
                }
                else
                {
                    string subtype = "";
                    string year = "";
                    string syear = "";
                    //과목 분류
                    if (rdo1.Checked)
                        subtype = rdo1.Text;
                    else if (rdo2.Checked)
                        subtype = rdo2.Text;
                    else if (rdo3.Checked)
                        subtype = rdo3.Text;
                    else if (rdo4.Checked)
                        subtype = rdo4.Text;
                 
                    //학년
                    if (rdoG1.Checked)
                        year = rdoG1.Text;
                    else if (rdoG2.Checked)
                        year = rdoG2.Text;
                    else if (rdoG3.Checked)
                        year = rdoG3.Text;
                    else if (rdoG4.Checked)
                        year = rdoG4.Text;

                    //학기
                    if (rdoSY1.Checked)
                        syear = rdoSY1.Text;
                    else if (rdoSY2.Checked)
                        syear = rdoSY2.Text;

                    if (lblYears[0].Text == "" || lblYears[0].Text == year)
                    {
                        for (int i = 0; i < 8; i++)
                        {
                            if (lblSubjects[i].Text == "")
                            {
                                cnt = i;
                                break;
                            }
                        }
                        lblSubjects[cnt].Text = tbSubject.Text;
                        lblSGrades[cnt].Text = tbSGrade.Text;
                        lblScores[cnt].Text = tbScore.Text;
                        lblTypes[cnt].Text = subtype;
                        lblYears[cnt].Text = year;
                        if (Double.Parse(lblScores[cnt].Text) == 4.5) lblGrades[cnt].Text = "A+";
                        else if (Double.Parse(lblScores[cnt].Text) >= 4) lblGrades[cnt].Text = "A";
                        else if (Double.Parse(lblScores[cnt].Text) >= 3.5) lblGrades[cnt].Text = "B+";
                        else if (Double.Parse(lblScores[cnt].Text) >= 3) lblGrades[cnt].Text = "B";
                        else if (Double.Parse(lblScores[cnt].Text) >= 2.5) lblGrades[cnt].Text = "C+";
                        else if (Double.Parse(lblScores[cnt].Text) >= 2) lblGrades[cnt].Text = "C";
                        else if (Double.Parse(lblScores[cnt].Text) >= 1.5) lblGrades[cnt].Text = "D+";
                        else if (Double.Parse(lblScores[cnt].Text) >= 1) lblGrades[cnt].Text = "D";
                        else if (Double.Parse(lblScores[cnt].Text) < 1) lblGrades[cnt].Text = "F";

                        List<string> q = new List<string>() { syear,year,subtype,
                            tbSubject.Text,tbSGrade.Text,lblGrades[cnt].Text,tbScore.Text};
                        dbp.Insert(q);

                        Sum += Double.Parse(lblSGrades[cnt].Text) * Double.Parse(lblScores[cnt].Text);
                        SgradeSum += Double.Parse(lblSGrades[cnt].Text);

                        avgScore = Sum / SgradeSum;
                        lblAvgScore.Text = avgScore.ToString();
                    }
                    else
                    {
                        MessageBox.Show("학년이 일치하지 않습니다.");
                    }
                }
            }
        }

        private void btnY1_Click(object sender, EventArgs e)
        {
            functions("1", "1");
        }

        private void btnY2_Click(object sender, EventArgs e)
        {
            functions("2", "1");
        }

        private void btnY3_Click(object sender, EventArgs e)
        {
            functions("1", "2");
        }

        private void btnY4_Click(object sender, EventArgs e)
        {
            functions("2", "2");
        }

       
        private void btnY3B1_Click(object sender, EventArgs e)
        {
            functions("1", "3");
        }

        private void btnY3B2_Click(object sender, EventArgs e)
        {
            functions("2", "3");
        }

        private void btnY4B1_Click(object sender, EventArgs e)
        {
            functions("1", "4");
        }

        private void btnY4B2_Click(object sender, EventArgs e)
        {
            functions("2", "4");
        }

        private void btnAllScore_Click(object sender, EventArgs e)
        {
            SgradeSum = 0;
            Sum = 0;
            avgScore = 0;
            Property p = new Property();
            List<string> pt = new List<string>();
            List<string> temp2 = new List<string>();
            int cnt = 0;
            int idx = 0;
            List<DBProperty> dbpRead = dbp.GetInfo();
            foreach (DBProperty d in dbpRead)
            {
                pt = new List<string>() { d.syear.ToString(), d.year.ToString()
                    , d.type, d.subject, d.sgrade.ToString(), d.grade, d.score.ToString() };
                for (int k = 0; k < pt.Count; k++)
                {
                    if (pt[k] == "" && cnt != 0)
                    {
                        pt[k] = temp2[k];
                    }
                }
                if (pt[5] != "S")
                {
                    SgradeSum += Double.Parse(pt[4]);
                    Sum += Double.Parse(pt[4]) * Double.Parse(pt[6]);
                }
                idx++;
                cnt++;
                
                temp2 = pt;
            }
            
            avgScore = Sum / SgradeSum;
            lblAllScore.Text = avgScore.ToString();

            Double needSGrade = 130 - SgradeSum;
            lblRestSGrade.Text = needSGrade.ToString();
            
        }
    }
}
